import boto3
import base64
import os
from botocore.exceptions import ClientError
from datetime import datetime
import json

# Initialize AWS clients
polly_client = boto3.client('polly')
s3_client = boto3.client('s3')

# Lambda function
def lambda_handler(event, context):
    try:
        # Parse the incoming JSON body from the API Gateway request
        body = json.loads(event['body'])  # Parse the body to a JSON object
        text = body.get('text', 'Hello, world!')  # Default message
        
        # Generate speech using Amazon Polly
        response = polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId='Joanna'  # Change the voice ID if needed
        )
        
        # Get the audio stream from the response
        audio_stream = response['AudioStream'].read()
        
        # Generate a unique file name based on the current timestamp
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        file_name = f"text-to-speech-{timestamp}.mp3"
        
        # S3 bucket name and key
        bucket_name = 's3-text-to-audio-files'
        s3_key = f"audio/{file_name}"  # File path inside the S3 bucket
        
        # Upload the audio stream to the S3 bucket
        s3_client.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=audio_stream,
            ContentType='audio/mpeg'  # Correct MIME type
        )
        
        # Generate a public S3 URL if the bucket permissions allow it
        s3_url = f"https://{bucket_name}.s3.amazonaws.com/{s3_key}"
        
        # Return success response with the S3 URL
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Text-to-Speech conversion successful",
                "s3_url": s3_url
            })
        }
    except ClientError as e:
        # Handle AWS service errors
        print(f"ClientError: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Error interacting with AWS services",
                "error": str(e)
            })
        }
    except Exception as e:
        # Handle generic errors
        print(f"Exception: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "An unknown error occurred",
                "error": str(e)
            })
        }
